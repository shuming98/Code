<?php echo $__env->make('cart.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="container">
	<form action="<?php echo e(url('cart')); ?>" method="post">
		<?php echo e(csrf_field()); ?>

		用户名<input type="text" name="mobile" value="<?php echo e(old('mobile')); ?>">
		
		<?php if(count($errors)>0): ?>
		<div class="alert alert-success">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<input type="submit" value="提交">
	</form>
</body>
</html>