<html><head>
<meta content="text/html; charset=UTF-8" http-equiv="content-type">
<meta charset="utf-8">
<title>注册点点贷会员领10000元体验金+100元红包 - 点点贷 </title>
<meta content="注册,点点贷,红包,体验金,体验宝,点点贷理财,返现 " name="keywords">
<meta content="注册点点贷会员即领10000元体验金+100元红包，投资体验宝，立享3天8.8%年化收益，注册7天内，完成首次投资送等额体验金，投资任意产品（除体验宝），立享超高返现，返现高至10000元。" name="description">
<link type="text/css" rel="stylesheet" href="/css/common.css">
<link type="text/css" rel="stylesheet" href="/css/reg.css">

</head>

<body class="nwd_index"><div class="mboxDefault" id="mbox-target-global-mbox-1458134936554-258397" style="visibility: visible; display: block;"></div><div class="mboxDefault" id="mbox-target-global-mbox-1458040677304-320799" style="visibility: visible; display: block;"></div>
<!--header start-->
<!--main-->
				<!---静态化 - 头部内容---->
<!--main-->

		<div class="clearfix simpleHead01">
			<div class="fl">
		    	<a href="#"><img height="52" style="vertical-align: initial;" alt="点点贷" src="/image/logo_all.png"></a><span>注册</span>
		    </div>
		    <div class="fr"><span class="fc_6">已有帐号？<a class="blue" href="#">立即登录</a></span></div>
		</div>
		<div id="reglogin" class="nwd-banner">
			<div class="nwd_loginPos">
				<!--<div class="fc_white" style="position: absolute;top: 120px;left: 20px;">
					<p class="fs_30">新手特权奖励 </p>
					<p class="fs_16 mt_15">动动手指，开启财富增值大门</p>
				</div>-->
				<div class="clearfix nwd_loginOut">
					<div class="content_box banner-Word">
						<h2>注册送10000元体验金+100元红包</h2>
					</div>
					<form action="" method="post">
						<?php echo e(csrf_field()); ?>

                    <div class="content_box pb_20">
						<label class="input_text yzm3">
							<input type="text" class="inp_bor inpIco3" placeholder="手机号" id="u" name="mobile">
						</label>
                        <label class="input_text yzm3">
							<input type="text" class="inp_bor inpIco3" placeholder="用户名" id="uname" name="name">
						</label>
                        <label class="input_text yzm3">
							<input type="text" class="inp_bor inpIco3" placeholder="Email" id="email" name="email">
						</label>
                        <label class="input_text yzm3">
							<input type="text" class="inp_bor inpIco3" placeholder="密码" id="pwd" name="password">
						</label>
                        <label class="input_text yzm3">
							<input type="text" class="inp_bor inpIco3" placeholder="确认密码" id="repwd" name="password_confirmation">
						</label>
						<!--div class="input_prompt"> <span class="fs_14 fc_6" id="mobileMsg" style="display: block;"><i class="ico ico_s14 ico3"></i>手机号码不能为空</span>
                        </div-->
						<label class="input_text yzm3"><i class="fr yzm_img"><img width="80" height="32" src="/image/refresh.jpg" id="imgc"></i>
							<input type="text" class="inp_bor inpIco5" placeholder="验证码" id="imgcode" name="imgcode">
						</label>
						<input type="submit" value="免费注册" class="btn_resize btn_orange w_10  mb_10" id="submitBtn">
						<div class="fc_9">注册即视为同意<a href="#" class="fc_blue">《点点贷用户协议》</a></div>
					</div>
                    </form>
				</div>
			</div>
		</div>
		<div class="newmainbg">
			<div class="title reg_step1">
				<h3>第1重大礼</h3>
				<p>注册即送1万元体验金+100元红包
					<!--<span>体验金与红包已发至您的个人账户</span>-->
				</p>
			</div>

			<div class="title reg_step2">
				<h3>第2重大礼</h3>
				<p>我出本金，你赚收益，体验投资乐趣
					<span>投资体验宝，立享3天8.8%预期年化收益</span>
				</p>
			</div>

			<div class="reg_step2_1">
				<div class="tiyanbao">体验宝</div>
				<div class="tybleft fl">
					<em class="fc_orange airal">8.8%</em><span>预期年化</span>
				</div>
				<div class="tybright fr">
					<em class="fc_6 airal">3天</em><span>期限</span>
				</div>
				<div class="addtyb"><a href="#" target="_blank">立即抢购</a></div>
			</div>

			<div class="title reg_step3">
				<h3>第3重大礼</h3>
				<p> 一份本金，双份收益，投多少送多少
					<span>注册7天内，完成首次投资送等额体验金</span>
				</p>
			</div>

			<div class="reg_step3_1">


				<div style="overflow: hidden;height: 260px;" class="contain-three">
				<!--切换-->
			<div class="page">
				<div class="section1">
					<div class="main-box">
						<div class="banner" style="transform: translateX(0px);">

							<div style="opacity: 1;" type="1" class="item middle">
								<div class="main-text">
									<div class="cont">
										<h6>财神道</h6>

										<p class="profit"><b>16.00</b><span>%</span></p>
									</div>
								</div>
								<div class="main-content">
									<div class="bg-board"></div>
									<div class="details-box">
										<h4 act="name" class="ta-c font-bold">财神道</h4>
										<div class="profit" style="display: none;">
										</div>
										<p class="size14 remark ta-c">新用户专享</p>

										<table>
											<tbody>
												<tr>
													<td class="pr10">16%</td>
													<td class="pl10">7天</td>
												</tr>
												<tr>
													<th class="pr10">预期年化</th>
													<th class="pl10">限期</th>
												</tr>
											</tbody>
										</table>
										<p class="lineshow">适用于本金保障计划</p>
										<a class="addmoney" target="_blank" href="#">立即抢购</a>

									</div>
								</div>
								<div class="wave"></div>
							</div>

							<div style="opacity: 1;" type="0" class="item middle active">
								<div class="main-text">
									<div class="cont">
										<h6>季季丰</h6>

										<p class="profit"><b>6.00</b><span>%</span></p>
									</div>
								</div>
								<div class="main-content">
									<div class="bg-board"></div>
									<div class="details-box">
										<h4 act="name" class="ta-c font-bold">季季丰</h4>
										<div class="profit" style="display: none;">
										</div>
										<p class="size14 remark ta-c">进阶产品</p>

										<table>
											<tbody>
												<tr>
													<td class="pr10">6%</td>
													<td class="pl10">3个月</td>
												</tr>
												<tr>
													<th class="pr10">预期年化</th>
													<th class="pl10">期限</th>
												</tr>
											</tbody>
										</table>
										<p class="lineshow">适用于本金保障计划</p>
										<a class="addmoney" target="_blank" href="#">立即抢购</a>

									</div>
								</div>
								<div class="wave"></div>
							</div>
							<div style="opacity: 1;" type="2" class="item middle">
								<div class="main-text">
									<div class="cont">
										<h6>嘉利宝</h6>

										<p class="profit"><b>11.00</b><span>%</span></p>
									</div>
								</div>
								<div class="main-content">
									<div class="bg-board"></div>
									<div class="details-box">
										<h4 act="name" class="ta-c font-bold">嘉利宝</h4>
										<div class="profit" style="display: none;">
										</div>
										<p class="size14 remark ta-c">进阶产品</p>

										<table>
											<tbody>
												<tr>
													<td class="pr10">11%</td>
													<td class="pl10">12个月</td>
												</tr>
												<tr>
													<th class="pr10">预期年化</th>
													<th class="pl10">期限</th>
												</tr>
											</tbody>
										</table>
										<p class="lineshow">适用于本金保障计划</p>
										<a class="addmoney" target="_blank" href="#">立即抢购</a>

									</div>
								</div>
								<div class="wave"></div>
							</div>

							<div style="opacity: 1;" type="3" class="item middle">
								<div class="main-text">
									<div class="cont">
										<h6>月月盈</h6>

										<p class="profit"><b>10.00</b><span>%</span></p>
									</div>
								</div>
								<div class="main-content">
									<div class="bg-board"></div>
									<div class="details-box">
										<h4 act="name" class="ta-c font-bold">月月盈</h4>
										<div class="profit" style="display: none;">
										</div>
										<p class="size14 remark ta-c">进阶产品</p>

										<table>
											<tbody>
												<tr>
													<td class="pr10">10%</td>
													<td class="pl10">12个月</td>
												</tr>
												<tr>
													<th class="pr10">预期年化</th>
													<th class="pl10">期限</th>
												</tr>
											</tbody>
										</table>
										<p class="lineshow">适用于本金保障计划</p>
										<a class="addmoney" target="_blank" href="#">立即抢购</a>

									</div>
								</div>
								<div class="wave"></div>
							</div>
						</div>
						<div class="arrow-box">
							<div class="arrows">
								<a class="left-arrow"></a>
								<a class="right-arrow"></a>
							</div>
						</div>
					</div>
				</div>
			</div>
  <!--切换-->
		</div>

			</div>


		</div>
		<div class="laststep">
			<div class="lastMsg">
				<div class="lastName">截至目前为止累计交易人次</div>
				<p style="padding-top: 0;"><em class="jyrc_money">10,403,634</em>人</p>
				<p><a href="javascript:;" class="myreglink">加入我们</a></p>
			</div>
		</div>





	<div style="border-top: 1px solid #e4e7ec;">
		<div class="login_foot w1000 txcenter">
			<p class="fc_9 fs_12">Copyright &copy; 2016 点点贷（www.dddai.com）&#12288;版权所有；市场有风险，投资需谨慎，营造合法、诚信借贷环境。</p>
		    <div class="line3 mt_10">
		        <a href="#" target="_blank" class="img1" rel="nofollow"><img width="70" height="32" src="/image/px.gif"></a>
		            <a href="#" target="_blank" class="img2" rel="nofollow"><img width="70" height="32" src="/image/px_002.gif"></a>
		            <a href="#" target="_blank" class="img3" rel="nofollow"><img width="70" height="32" src="/image/px_002.gif"></a>
		            <a href="#" target="_blank" class="img4" rel="nofollow"><img width="70" height="32" src="/image/px.gif"></a>
		            <a href="#" target="_blank" class="img5" rel="nofollow"><img width="70" height="32" src="/image/px.gif"></a>
		    		<a href="#" target="_blank" class="img6" rel="nofollow"><img width="70" height="32" src="/image/px.gif"></a>
		        	<a href="#" target="_blank" class="img7" rel="nofollow"><img width="70" height="32" src="/image/px.gif"></a>
		        	<a href="#" target="_blank" class="img8" rel="nofollow"><img width="70" height="32" src="/image/px.gif"></a>
		        	<a href="#" target="_blank" class="img9" rel="nofollow"><img width="70" height="32" src="/image/px.gif"></a>
		    </div>
		</div>
	</div>

<!--main  end-->
<!--main  end-->

</body></html>
