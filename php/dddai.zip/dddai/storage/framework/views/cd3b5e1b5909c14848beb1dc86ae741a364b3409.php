<?php echo $__env->make('template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div>
	<?php $__env->startSection('content'); ?>
	<?php echo $__env->yieldSection(); ?>
</div>

<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>