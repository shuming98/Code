<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link type="text/css" rel="stylesheet" href="/css/common.css">
    <link type="text/css" rel="stylesheet" href="/css/index.css">
    <link rel="stylesheet" href="/css/app.css">
  </head>
  <body class="container index_niwo holiday_bg">
    <?php echo $__env->make('template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <form method="post" action="/pays/index.php" style="width:250px;margin:auto">
        <?php echo e(csrf_field()); ?>

        <h1>订单平台</h1>
        <p><input type="hidden" name="v_mid" value="<?php echo e($v_mid); ?>"></p>
        <p>订单编号<input type=text name="v_oid" value="<?php echo e($v_oid); ?>"></p>
        <p>订单总金额<input type=text name="v_amount" value="<?php echo e($v_amount); ?>"></p>
        <p><input type="hidden" name="v_moneytype" value="<?php echo e($v_moneytype); ?>"></p>
        <p><input type="hidden" name="v_url" value="<?php echo e($v_url); ?>"></p>
        <p><input type="hidden" name="v_md5info" value="<?php echo e($v_md5info); ?>"></p>
        <input type="submit" class="btn btn-primary" value="立即支付">
    </form>
    <?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
</html>
