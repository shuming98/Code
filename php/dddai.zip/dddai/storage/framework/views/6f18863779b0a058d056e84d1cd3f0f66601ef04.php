<?php echo $__env->make('cart.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="container">
	<h1>laravel/reource</h1>
</body>
</html>