<?php
//B(ought)投资人
namespace App;

use Illuminate\Database\Eloquent\Model;

class Bid extends Model
{	
    protected $primaryKey = 'bid';
}
