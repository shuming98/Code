<!--提示end-->
<!--foot Start-->
  <div class="h35 clearfix"></div> 
  <div class="foot1 wt_1000"> 
   <div class="clearfix out"> 
    <div class="l"> 
     <ul class="clearfix fNav"> 
      <li> <a class="span01" href="javascript:void(0);">关于我们</a><br /> <a class="a01" href="javascript:void(0);"><i></i>公司简介</a><br /> <a class="a01" href="javascript:void(0);"><i></i>业绩报告</a><br /> <a class="a01" href="javascript:void(0);"><i></i>法律法规</a><br /> </li> 
      <li> <a class="span01" href="javascript:void(0);">安全保障</a><br /> <a class="a01" href="javascript:void(0);"><i></i>本金保障</a><br /> <a class="a01" href="javascript:void(0);"><i></i>风控保障</a><br /> <a class="a01" href="javascript:void(0);"><i></i>账户安全</a><br /> </li> 
      <li> <a class="span01" href="javascript:void(0);">帮助中心</a><br /> <a class="a01" href="javascript:void(0);"><i></i>如何投资</a><br /> <a class="a01" href="javascript:void(0);"><i></i>如何借款</a><br /> <a class="a01" href="javascript:void(0);"><i></i>网站资费</a><br /> </li> 
      <li> <a class="span01" href="javascript:void(0);">用心服务</a><br /> <a class="a01" href="javascript:void(0);"><i></i>联系我们</a><br /> <a class="a01" href="javascript:void(0);"><i></i>网站地图</a><br /> <a class="a01" href="javascript:void(0);"><i></i>服务地区</a><br /> </li> 
     </ul> 
    </div> 
    <div class="r"> 
     <ul> 
      <li class="line1"><span class="fs_16 pr_20 fc_3">热线电话</span>(服务时间 09 : 00 - 21 : 00 )</li> 
      <li class="line2"><span class="fs_32 bold fc_6 pr_20">010-5715520</span> <span style="color:#dedede"> 95. </span></li> 
      <li class="line3 fc_3">关注我们<a rel="nofollow" class="ico" href="javascript:void(0);"><i class="i_s"></i></a><i onclick="showCon_2()" class="i_q"></i></li> 
     </ul> 
    </div> 
   </div> 
   <div class="footlink footlink1"> 
    <span class="bt">合作伙伴：</span> 
    <!--<span class="lg_box fl_img1"><a href="javascript:void(0);" >&nbsp;</a></span>--> 
    <span class="lg_box fl_img2"><a href="javascript:void(0);">&nbsp;</a></span> 
    <span class="lg_box fl_img3"></span> 
    <span class="lg_box fl_img4"><a href="javascript:void(0);">&nbsp;</a></span> 
    <span class="lg_box fl_img5"></span> 
    <span class="lg_box fl_img6"></span> 
    <span class="lg_box fl_img7"></span> 
    <span class="lg_box fl_img8"></span> 
    <span class="lg_box fl_img9"></span> 
    <a rel="nofollow" class="lg_box fl_img10" href="javascript:void(0);"></a> 
   </div> 
  </div> 
  <div class="clearfix foot2 wb_1000"> 
   <div class="out ff"> 
    <div class="line1"> 
     <ul class="lunbo1" style="margin-top: -48px;"> 
      <li> <a href="javascript:void(0);">现金宝</a>丨 <a href="javascript:void(0);">人人贷</a>丨 <a href="javascript:void(0);">陆金所</a>丨 <a href="javascript:void(0);">拍拍贷</a>丨 <a href="javascript:void(0);">南方基金</a>丨 <a href="javascript:void(0);">定期宝</a>丨 <a href="javascript:void(0);">活期宝</a>丨 <a href="javascript:void(0);">安心贷</a>丨 <a href="javascript:void(0);">有利网</a>丨 <a href="javascript:void(0);">天弘基金</a>丨 <a href="javascript:void(0);">余额宝收益</a>丨 </li> 
      <li> <a href="javascript:void(0);">货币基金收益排行</a>丨 <a href="javascript:void(0);">基金公司排名</a>丨 <a href="javascript:void(0);">基金经理排名</a>丨 <a href="javascript:void(0);">证券公司排名</a>丨 <a href="javascript:void(0);">基金排名</a>丨 <a href="javascript:void(0);">期货公司排名</a>丨 <a href="javascript:void(0);">炒外汇入门</a>丨 <a href="javascript:void(0);">什么是基金</a>丨 <a href="javascript:void(0);">投资产品排行</a>丨 <a href="javascript:void(0);">股票入门基础知识</a>丨 <a href="javascript:void(0);">网络贷款平台</a>丨 </li> 
      <li> <a href="javascript:void(0);">贷款计算器</a>丨 <a href="javascript:void(0);">商业贷款计算器</a>丨 <a href="javascript:void(0);">按揭贷款计算器</a>丨 <a href="javascript:void(0);">工资计算器</a>丨 <a href="javascript:void(0);">提前还贷计算器</a>丨 <a href="javascript:void(0);">个人所得税计算器</a>丨 <a href="javascript:void(0);">车险计算器</a>丨 <a href="javascript:void(0);">利息计算器</a>丨 <a href="javascript:void(0);">分期付款计算器</a>丨 <a href="javascript:void(0);">等额本息还款计算器</a>丨 <a href="javascript:void(0);">存款计算器</a>丨 <a href="javascript:void(0);">中国银行贷款计算器</a>丨 <a href="javascript:void(0);">工行贷款计算器</a> 丨 <a href="javascript:void(0);">理财计算器</a>丨 <a href="javascript:void(0);">复利计算器</a> 丨 <a href="javascript:void(0);">资讯频道</a>丨 <a href="javascript:void(0);">标签</a> <a href="javascript:void(0);">各国货币</a>| <a href="javascript:void(0);">融资租赁</a>| <a href="javascript:void(0);">贵金属</a>| <a href="javascript:void(0);">期权交易</a>| <a href="javascript:void(0);">贷款知识</a>| <a href="javascript:void(0);">金融知识</a>| <a href="javascript:void(0);">银行理财产品</a>| <a href="javascript:void(0);">银行网点</a>| <a href="javascript:void(0);">信用卡</a>| <a href="javascript:void(0);">栏目列表</a>| <a href="javascript:void(0);">A</a>| <a href="javascript:void(0);">B</a>| <a href="javascript:void(0);">C</a>| <a href="javascript:void(0);">D</a>| <a href="javascript:void(0);">E</a>| <a href="javascript:void(0);">F</a>| <a href="javascript:void(0);">G</a>| <a href="javascript:void(0);">H</a>| <a href="javascript:void(0);">I</a>| <a href="javascript:void(0);">J</a>| <a href="javascript:void(0);">K</a>| <a href="javascript:void(0);">L</a>| <a href="javascript:void(0);">M</a>| <a href="javascript:void(0);">N</a>| <a href="javascript:void(0);">O</a>| <a href="javascript:void(0);">P</a>| <a href="javascript:void(0);">Q</a>| <a href="javascript:void(0);">R</a>| <a href="javascript:void(0);">S</a>| <a href="javascript:void(0);">T</a>| <a href="javascript:void(0);">U</a>| <a href="javascript:void(0);">V</a>| <a href="javascript:void(0);">W</a>| <a href="javascript:void(0);">X</a>| <a href="javascript:void(0);">Y</a>| <a href="javascript:void(0);">Z</a>|丨 </li> 
     </ul> 
    </div> 
    <div class="line2">
      Copyright &copy; 2016 点点贷（www.dddai.com）　版权所有；市场有风险，投资需谨慎，营造合法、诚信借贷环境。 
    </div> 
    <div class="police"> 
     <a href="javascript:void(0);" class="img1" rel="nofollow"><img width="70" height="32" src="/image/px_002.gif" /></a> 
     <a href="javascript:void(0);" class="img2" rel="nofollow"><img width="70" height="32" src="/image/px_002.gif" /></a> 
     <a href="javascript:void(0);" class="img3" rel="nofollow"><img width="70" height="32" src="/image/px.gif" /></a> 
     <a href="javascript:void(0);" class="img4" rel="nofollow"><img width="70" height="32" src="/image/px_002.gif" /></a> 
     <a href="javascript:void(0);" class="img5" rel="nofollow"><img width="70" height="32" src="/image/px_002.gif" /></a> 
     <a href="javascript:void(0);" class="img6" rel="nofollow"><img width="70" height="32" src="/image/px.gif" /></a> 
     <a href="javascript:void(0);" class="img7" rel="nofollow"><img width="70" height="32" src="/image/px_002.gif" /></a> 
     <a href="javascript:void(0);" class="img8" rel="nofollow"><img width="70" height="32" src="/image/px_002.gif" /></a> 
     <a href="javascript:void(0);" class="img9" rel="nofollow"><img width="70" height="32" src="/image/px_002.gif" /></a> 
    </div> 
   </div> 
  </div> 
  <!-- weixin start --> 
  <div class="plusBankBg" style="height: 1169px;"></div> 
  <div class="plusBank2"> 
   <div class="clearfix ewm01"> 
    <a onclick="closeAll_2()" class="fr plus_c"></a> 关注点点贷官方微信 
   </div> 
   <div class="ewm02"> 
    <img width="430" height="430" src="/image/ewm.jpg" /> 
   </div> 
  </div> 
  <!-- weixin end --> 
  <!--foot End-->