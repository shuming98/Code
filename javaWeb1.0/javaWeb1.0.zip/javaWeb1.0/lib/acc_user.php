<?php 
	if(!isset($_SESSION['user_account'])){
	 	header('Location:../../index.php');
	 	exit;
	 }
 ?>
