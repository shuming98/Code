<?php 
if(!isset($_SESSION['permission'])){
	header('Location:../../index.php');
	exit;
}
 ?>
