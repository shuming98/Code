<?php 
/***
 * php配置文件
 ***/

return array(
	'host'=>'127.0.0.1',
	'user'=>'root',
	'passwd'=>'123456',
	'db'=>'java_web',
	'charset'=>'utf8',
	'salt'=>'OP1AS5D$#:9;'
);
?>
